urls = {
"음식물쓰레기종합배출내역":"http://apis.data.go.kr/B552584/RfidFoodWasteService/getTotalDayList?serviceKey=IRQXxLsPnSjL0QMQtCNavq9YiuyyOFe1Bs8NsgESLaP6O%2Bd4qHufr1JnpK%2FvmupHoBuMVqM6Pd2ZpmEzuXcWIg%3D%3D&type=json&disYear=2018&disMonth=05&page=1&rowNum=10",
    "자전거사고다발지역정보서비스":"http://apis.data.go.kr/B552061/frequentzoneBicycle/getRestFrequentzoneBicycle?serviceKey=IRQXxLsPnSjL0QMQtCNavq9YiuyyOFe1Bs8NsgESLaP6O%2Bd4qHufr1JnpK%2FvmupHoBuMVqM6Pd2ZpmEzuXcWIg%3D%3D&searchYearCd=2017050&siDo=11",
    "이중섭미술관이중섭작품":"http://data.seogwipo.go.kr/openapi/service/rest/ljsLjs?serviceKey=IRQXxLsPnSjL0QMQtCNavq9YiuyyOFe1Bs8NsgESLaP6O%2Bd4qHufr1JnpK%2FvmupHoBuMVqM6Pd2ZpmEzuXcWIg%3D%3D&_type=json",
    "대기오염시도별실시간측정정보조회":"http://openapi.airkorea.or.kr/openapi/services/rest/ArpltnInforInqireSvc/getCtprvnRltmMesureDnsty?serviceKey=IRQXxLsPnSjL0QMQtCNavq9YiuyyOFe1Bs8NsgESLaP6O%2Bd4qHufr1JnpK%2FvmupHoBuMVqM6Pd2ZpmEzuXcWIg%3D%3D&numOfRows=10&pageSize=10&pageNo=1&startPage=1&sidoName=%EC%84%9C%EC%9A%B8&ver=1.3&_returnType=json",
    "금천구동네예보조회":"http://newsky2.kma.go.kr/service/SecndSrtpdFrcstInfoService2/ForecastSpaceData?serviceKey=IRQXxLsPnSjL0QMQtCNavq9YiuyyOFe1Bs8NsgESLaP6O%2Bd4qHufr1JnpK%2FvmupHoBuMVqM6Pd2ZpmEzuXcWIg%3D%3D&base_date=20180704&base_time=2300&nx=59&ny=124&numOfRows=10&pageSize=10&pageNo=1&startPage=1&_type=json"
}
#금천구동네예보조회 base_time갱신 : 0200, 0500, 0800, 1100, 1400, 1700, 2000, 2300 (1일 8회)
htmlPath="Views"
jsonPath="data"
localhost="http://localhost/app.py"


category = {
    "POP" : {"item":"강수확률","unit":"%"},
    "PTY" : {"item":"강수형태","unit":""},
    "R06" : {"item":"6시간 강수량","unit":"mm"},
    "REH" : {"item":"습도","unit":"%"},
    "S06" : {"item":"6시간 신적설","unit":"cm"},
    "SKY" : {"item":"하늘상태","unit":""},
    "T3H" : {"item":"3시간 기온","unit":"℃"},
    "TMN" : {"item":"아침 최저기온","unit":"℃"},
    "TMX" : {"item":"낮 최고기온","unit":"℃"},
    "UUU" : {"item":"풍속(동서성분)","unit":"m/s"},
    "VVV" : {"item":"풍속(남북성분)","unit":"m/s"},
    "WAV" : {"item":"파고","unit":"M"},
    "VEC" : {"item":"풍향","unit":"m/s"},
    "WSD" : {"item":"풍속","unit":""}
}
disDay = {
    "1":"일",
    "2":"월",
    "3":"화",
    "4":"수",
    "5":"목",
    "6":"금",
    "7":"토"
}