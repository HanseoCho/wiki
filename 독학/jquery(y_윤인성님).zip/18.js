//모듈을 추출한다.
const express = require('express')
const app = express()

app.use(express.static('public')) //public은 폴더의 이름이고
                                  //폴더의 모든내용을 get으로 자동생성해준다.

app.get('/', (req,res)=>{               // /로 접근시 표기
    res.send('<h1>HelloWorld</h1')
});

app.listen(52273, ()=>{
    console.log('Server Running at http://127.0.0.1:52273')
})
