#!python
# coding: utf-8
import common,cgi

cgi = cgi.FieldStorage()
common.start(cgi)
