# coding:UTF-8
import json, urllib, requests, datetime, os,config
#상단부분의 체크리스트를 뿌려준다
def start(cgi):
    if "result" in cgi:
        if "key" in cgi:
            getView("list")
            keyView(int(cgi["key"].value))
        else:
            getView("list")
            jsonListView()
    elif "dir" in cgi:
        jsonView(cgi["dir"].value)
    else :
        getView("index")
        getData(cgi)
        hiScript()


def getView(name):
    with open("{0}/{1}.html".format(config.htmlPath,name),"r",encoding="utf-8") as f :
        print("Content-Type: text/html; charset=utf-8\n\n")
        print(f.read())

def getData(params):
    if "oper" in params:
        params["oper"]
        result = []
        nameAry = []
        if type(params["oper"]) is list:
            for key in params["oper"]:
                nameAry.append(key.value)
                #print(key.value)
        else:
            nameAry.append(params["oper"].value)
        
        writeAndReturn(nameAry)
            #print(params["oper"].value)
    else :
        print("대기중입니다.")
#화면에 바로 뿌려주려했으나 보여주는 버튼을 따로만들거라서 return은없음
def writeAndReturn(nameAry):
    date = datetime.datetime.now()
    dir_nm = "{0}/{1}/{2}".format(os.getcwd(),config.jsonPath,date.strftime("%Y%m%d_%H%M%S"))    
    print(dir_nm)
    if not os.path.isdir(os.getcwd()+"/"+config.jsonPath):
        os.mkdir(config.jsonPath)
    if not os.path.isdir(dir_nm):        
        os.mkdir(dir_nm)
    for name in nameAry:
        if name in config.urls:
            data = requests.get(config.urls[name]).text
            with open("{0}/{1}.json".format(dir_nm, name), "w", encoding="utf8") as f:
                f.write(data)
        else:
            break
    print("데이터 수집완료")

def jsonListView():
    arr = os.listdir(config.jsonPath)
    brTag()
    for i in range(len(arr)):
        html = '''<a href="{0}?result=1&key={1}">{2}</a><br>'''.format("app.py",i,arr[i])
        print(html)

def keyView(key):
    brTag()
    arr = os.listdir(config.jsonPath)
    
#    print(arr[key])
#    print(os.listdir("{0}/{1}".format(config.jsonPath,arr[key+1])))
    info = {"dir":"{0}/{1}".format(config.jsonPath,arr[key])}
    dirInfo = os.listdir("{0}".format(info["dir"]))
    for i in dirInfo:
        info["name"] = i
        jsonPrint(info)
        brTag()
    

def brTag():
    print("<br>")      
def nbspTag(num):
    html = ""
    for i in range(num):
        html += "&nbsp;"
    return html

def jsonPrint(info):
    print(info["name"])
    brTag()
    
    ##test 태그이벤트 확인
    print("<a class='abtn' href=#'>print추가하는 태그 이벤트 확인</a><br>")
    script = '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>'        
    script += '''
    <script>
        $(function(){
            $(".abtn").on('click',function(){
                alert("print로 추가되는 친구에게 이벤트 추가하기")
                return false
            });
        })
    </script>
    '''
    print(script)
    ##

    with open("{0}/{1}".format(info["dir"],info["name"]),"r",encoding="utf-8") as f :
        print(maketable(json.loads(f.read()),info))
        
        
#테이블 만들어줌(해당 json객체와 이름을 넘겨주면 테이블을 만든다.)
def maketable(json,info):
    name = info["name"][:-5]
    fileDir = info["dir"]+"/"+info["name"]
    html = "<table style='border: 1px solid black;'>"
    if name == "음식물쓰레기종합배출내역":
        html += "<tr><td>배출년도</td><td>배출월</td><td>배출일</td><td>요일갯수</td><td>일평균배출량</td><td>일평균배출횟수</td></tr>"
        #html += "<tr><td>배출년도</td><td>배출월</td><td>배출일</td><td>요일갯수(disDayCount)</td><td>일평균배출량(dayAverQuantity)</td><td>일평균배출횟수(dayAverCount)</td></tr>"
        for row in json["data"]["list"]:
            html += "<tr style='text-align: center;'><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td></tr>".format(row["disYear"],row["disMonth"],config.disDay[str(row["disDay"])],row["disDayCount"],row["dayAverQuantity"],row["dayAverCount"])

            #row["fcstValue"]
            #+config.category[row["category"]]["unit"]
        html+="<tr><td>총데이터수</td><td>{0}</td></tr>".format(json["data"]["count"])
        html+="<tr><td>현재데이터</td><td>{0}</td></tr>".format(json["data"]["count"])
    elif name == "자전거사고다발지역정보서비스":
        html += "<tr><td>장소</td><td>세부장소</td><td>사고횟수</td></tr>"
        #html += "<tr><td>장소(spot)</td><td>세부장소(spotname)</td><td>사고횟수(CO)</td></tr>"
        for row in json["searchResult"]["frequentzone"]:
            html += "<tr style='text-align: center;'><td>{0}</td><td>{1}</td><td>{2}</td></tr>".format(row["spot"],row["spotname"],row["occrrnc_co"]+row["dthinj_co"]+row["death_co"]+row["serinj_co"]+row["ordnr_co"]+row["inj_co"])
        html+="<tr><td>총데이터수</td><td>{0}</td></tr>".format(json["totalCount"])
        html+="<tr><td>현재데이터</td><td>{0}</td></tr>".format(json["totalCount"])        
    elif name == "이중섭미술관이중섭작품":
        html += "<tr><td>작품제목</td><td>작품설명</td></tr>"
        #html += "<tr><td>작품제목(LSubject)</td><td>작품설명(LContents)</td></tr>"
        for row in json["response"]["body"]["items"]["item"]:
            html += "<tr style='text-align: center;'><td>{0}</td><td>{1}</td></tr>".format(row["LSubject"],row["LContents"])
        html+="<tr><td>총데이터수</td><td>{0}</td></tr>".format(json["response"]["body"]["totalCount"])
        html+="<tr><td>현재데이터</td><td>{0}</td></tr>".format(json["response"]["body"]["numOfRows"])    
    elif name == "대기오염시도별실시간측정정보조회":
        html += "<tr><td>통보날짜</td><td>측정망</td><td>측정장소</td><td>일산화탄소 지수</td><td>일산화탄소 농도</td><td></td><td>통합대기환경지수</td><td>통합대기환경수치</td><td>이산화질소 지수</td><td>이산화질소 농도</td><td>오존 지수</td><td>오존 농도</td><td>미세먼지 1시간 등급</td></tr>"
        #html += "<tr><td>dataTime</td><td>mangName</td><td>coGrade</td><td>coValue</td><td></td><td>khaiGrade</td><td>khaiValue</td><td>no2Grade</td><td>no2Value</td><td>o3Grade</td><td>o3Value</td><td>pm10Grade1h</td></tr>"
        for row in json["list"]:
            html += "<tr style='text-align: center;'><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td></td><td>{4}</td><td>{5}</td><td>{6}</td><td>{7}</td><td>{8}</td><td>{9}</td><td>{10}</td><td>{11}</td></tr>".format(row["dataTime"],row["mangName"],row["stationName"],row["coGrade"],row["coValue"],row["khaiGrade"],row["khaiValue"],row["no2Grade"],row["no2Value"],row["o3Grade"],row["o3Value"],row["pm10Grade1h"])
        html+="<tr><td>총데이터수</td><td>{0}</td></tr>".format(json["totalCount"])
        html+="<tr><td>현재데이터</td><td>{0}</td></tr>".format(json["parm"]["numOfRows"])
    elif name == "금천구동네예보조회":
        html += "<tr><td>예보일자</td><td>예보시각</td><td>구분</td><td>예보 값</td></tr>"
        for row in json["response"]["body"]["items"]["item"]:
            html += "<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td></tr>".format(row["fcstDate"],nbspTag(2)+row["fcstTime"],config.category[row["category"]]["item"],str(row["fcstValue"])+' '+config.category[row["category"]]["unit"])
            #row["fcstValue"]
            #+config.category[row["category"]]["unit"]
        html+="<tr><td>총데이터수</td><td>{0}</td></tr>".format(json["response"]["body"]["totalCount"])
        html+="<tr><td>현재데이터</td><td>{0}</td></tr>".format(json["response"]["body"]["numOfRows"])
    else:
        print("name이 없는데요")
    html += "<a href='?dir={0}'>json으로 보기</a>".format(fileDir)
    html += "</table>"
    return html

#스크립트부분            
def hiScript():
    script2 = '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>'
    script2 +='''
    <script>
    $(function(){
        $("#jget").on("click",function(){
            if ($("#jtext").val() == ""){
                alert("Json 링크를 입력해주세요")
                return false
            }
            else{
                $.ajax({"url":$("#jtext").val()}).done(function(data){
                    j = JSON.stringify(data)             
                    console.log(j)
                    $("#view").text(j)
                });
            }

        });
    });
    </script>
    '''
    print(script2)

#json화면에 뿌려주기
def jsonView(dir):
    print("Content-Type: text/html; charset=utf-8\n\n")
    with open("{0}".format(dir),"r",encoding="utf-8") as f :
        print(f.read())
