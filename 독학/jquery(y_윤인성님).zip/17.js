const http = require("http") //http모듈을 읽어들인다.

const server = http.createServer((request,response) => { //이렇게 만들면 서버라는 객체를 리턴해준다. 
    //요청 정보확인
    console.log(request.method);
    console.log(request.url);
    console.log();

    if(request.url === "/hello"){
        response.writeHead(200,{
            "Content-Type": "text/html"
        });
        response.write("<meta charset='utf-8'><h1>안녕하세요</h1>");  //응답 본문
        response.end();
    }else{

        //응답 방법 : 사용자에게 응답해주는 코드
        response.writeHead(200,{            //첫번째에 statusCode와 두번재에는 응답헤더와 관련되 객체 삽입
            "Content-Type": "text/html"
        });
        response.write("<h1>Hello World</h1>");  //응답 본문
        response.end();
    }
});
server.listen(52273, () =>{ // 사용안하는포트인 52273과 콜백함수
    console.log("server Running at http://127.0.0.1:52273")
});

// 익스프레스 라이브러리라는 Jquery 라이브러리가 있다.