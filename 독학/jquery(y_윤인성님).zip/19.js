//모듈을 추출한다.
const express = require('express')
const app = express()

// 변수를 선언
const items = [{
    name: '우유',
    price: '2000'
},{
    name: '홍차',
    price: '5000'    
},{
    name: '커피',
    price: '5000'    
}];



app.use(express.static('public')); //public은 폴더의 이름이고
                                  //폴더의 모든내용을 get으로 자동생성해준다.

app.get('/data.html', (request,response)=>{  
    console.log(request.url);             
    let output = "";
    output += "<!DOCTYPE HTML>";
    output += "<html>";
    output += "<head>";
    output += "     <title>Data HTML</title>"
    output += "</head>";
    output += "</html>";
    output += "<body>";    
    items.forEach(function(item){
        output += "<div>";
        output += " <h1>" + item.name +"</h1>";
        output += " <h2>" + item.price +"</h2>";
        output += "</div>";
    });
    output += "</body>";
    output += "</html>";
    response.send(output)
});
app.get('/data.json', (req,res)=>{               
    res.send(items)
});

app.listen(52273, ()=>{
    console.log('Server Running at http://127.0.0.1:52273')
})
